import XCTest
import CoreData
@testable import DemoTestapp


@MainActor
final class DocumentListViewModelTests: XCTestCase {
    var viewModel: DocumentListViewModel!
    var context: NSManagedObjectContext!

    override func setUp() {
        super.setUp()
        let previewController = PersistenceController.preview
        context = previewController.container.viewContext
        viewModel = DocumentListViewModel(context: context)
    }

    func test_FetchLocalDocuments() {
        viewModel.fetchLocalDocuments()
        XCTAssertFalse(viewModel.documents.isEmpty, "Should have loaded preview documents")
    }

    func test_CreateDocument() async {
        let initialCount = viewModel.documents.count
        await viewModel.createDocument(title: "Test Doc", isFavorite: true)
        XCTAssertEqual(viewModel.documents.count, initialCount + 1)
        XCTAssertTrue(viewModel.documents.contains { $0.title == "Test Doc" })
    }

    func test_DeleteDocument() async {
        guard let doc = viewModel.documents.first else {
            XCTFail("No document available to delete")
            return
        }
        let initialCount = viewModel.documents.count
        await viewModel.delete(doc)
        XCTAssertEqual(viewModel.documents.count, initialCount - 1)
    }
}
