import XCTest
@testable import DemoTestapp
import CoreData

@MainActor
final class DocumentEditViewModelTests: XCTestCase {

    var context: NSManagedObjectContext!

    override func setUpWithError() throws {
        context = PersistenceController(inMemory: true).container.viewContext
    }

    func testEditViewModelInitialization() throws {
       
        let document = Document(context: context)
        document.title = "Original Title"
        document.isFavorite = false
        document.createdAt = Date()
        document.id = "123"

  
        let viewModel = DocumentEditViewModel(document: document)


        XCTAssertEqual(viewModel.title, "Original Title")
        XCTAssertEqual(viewModel.isFavorite, false)
    }

    func testSaveChangesUpdatesDocumentAndMarksUnsynced() async throws {

        let document = Document(context: context)
        document.title = "Initial"
        document.isFavorite = false
        document.createdAt = Date()
        document.id = "123"

        let viewModel = DocumentEditViewModel(document: document)

   
        viewModel.title = "Updated"
        viewModel.isFavorite = true
        try await viewModel.saveChanges()

       
        XCTAssertEqual(document.title, "Updated")
        XCTAssertEqual(document.isFavorite, true)
        XCTAssertEqual(document.isSynced, NetworkMonitor.shared.isConnected)
    }
}
