import Foundation

class APIService {
    static let shared = APIService()
    private let baseURL = "https://67ff5bb258f18d7209f0debe.mockapi.io/documents"

    func fetchDocuments() async throws -> [DocumentDTO] {
        guard let url = URL(string: baseURL) else {
            throw URLError(.badURL)
        }
        let (data, _) = try await URLSession.shared.data(from: url)
        print("\(String(data: data, encoding: .utf8) ?? "No response")")
        return try JSONDecoder().decode([DocumentDTO].self, from: data)
    }

    func createDocument(_ dto: DocumentDTO) async throws {
        guard let url = URL(string: baseURL) else { throw URLError(.badURL) }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = try JSONEncoder().encode(dto)
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        _ = try await URLSession.shared.data(for: request)
    }

    func updateDocument(_ dto: DocumentDTO) async throws {
        guard let url = URL(string: "\(baseURL)/\(dto.docId)") else { throw URLError(.badURL) }
        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.httpBody = try JSONEncoder().encode(dto)
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        _ = try await URLSession.shared.data(for: request)
    }

    func deleteDocument(id: String) async throws {
        guard let url = URL(string: "\(baseURL)/\(id)") else { throw URLError(.badURL) }

        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"

        _ = try await URLSession.shared.data(for: request)
    }
}
