import Foundation
import CoreData

class SyncService {
    static let shared = SyncService()
    private let context = PersistenceController.shared.viewContext

    private init() {}

    @MainActor
    func startSync() {
        Task {
            await syncPendingDocuments()
            await syncDeletedDocuments()
        }
    }

    private func fetchUnsyncedDocuments() -> [Document] {
        let request: NSFetchRequest<Document> = Document.fetchRequest()
        request.predicate = NSPredicate(format: "isSynced == NO AND isDelet == NO")
        return (try? context.fetch(request)) ?? []
    }

    private func fetchDeletedDocuments() -> [Document] {
        let request: NSFetchRequest<Document> = Document.fetchRequest()
        request.predicate = NSPredicate(format: "isDelet == YES")
        return (try? context.fetch(request)) ?? []
    }

    @MainActor
    private func syncPendingDocuments() async {
        let unsynced = fetchUnsyncedDocuments()
        for doc in unsynced {
            let dto = DocumentDTO(
                docId: doc.id ?? UUID().uuidString,
                docName: doc.title ?? "Untitled",
                createdDate: formatDate(doc.createdAt),
                isFavourite: doc.isFavorite
            )

            do {
                if docExistsOnServer(id: doc.id ?? "") {
                    try await APIService.shared.updateDocument(dto)
                } else {
                    try await APIService.shared.createDocument(dto)
                }
                doc.isSynced = true
            } catch {
                print("\(doc.title ?? "Untitled"), error: \(error)")
            }
        }

        try? context.save()
    }

    @MainActor
    private func syncDeletedDocuments() async {
        let deleted = fetchDeletedDocuments()
        for doc in deleted {
            do {
                try await APIService.shared.deleteDocument(id: doc.id ?? "")
                context.delete(doc)
            } catch {
                print("\(doc.title ?? "Untitled"), error: \(error)")
            }
        }

        try? context.save()
    }

    private func docExistsOnServer(id: String) -> Bool {
        // Placeholder: always assume it exists
        return true
    }

    private func formatDate(_ date: Date?) -> String {
        guard let date = date else { return "1970-01-01T00:00:00Z" }
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
        return formatter.string(from: date)
    }
}
