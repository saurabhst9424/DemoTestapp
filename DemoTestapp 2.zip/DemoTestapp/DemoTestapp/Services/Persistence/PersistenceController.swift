
import Foundation
import CoreData
final class PersistenceController {
    static let shared = PersistenceController()
    let container: NSPersistentContainer

    var viewContext: NSManagedObjectContext {
        container.viewContext
    }

    init(inMemory: Bool = false) {
        container = NSPersistentContainer(name: "DemoTestapp")
        if inMemory {
            container.persistentStoreDescriptions.first?.url = URL(fileURLWithPath: "/dev/null")
        }
        container.loadPersistentStores { _, error in
            if let error = error as NSError? {
                fatalError("Core Data load error: \(error)")
            }
        }
    }

    func save() {
        if viewContext.hasChanges {
            try? viewContext.save()
        }
    }
}

extension PersistenceController {
    static var preview: PersistenceController = {
        let controller = PersistenceController(inMemory: true)

        // Add preview data
        let viewContext = controller.container.viewContext
        for i in 0..<5 {
            let newDoc = Document(context: viewContext)
            newDoc.id = "\(i)"
            newDoc.title = "Preview Doc \(i)"
            newDoc.createdAt = Date()
            newDoc.isFavorite = (i % 2 == 0)
            newDoc.isSynced = true
        }

        do {
            try viewContext.save()
        } catch {
            fatalError("Failed to save preview data: \(error)")
        }

        return controller
    }()
}
