import Foundation
import CoreData

@MainActor
class DocumentEditViewModel: ObservableObject {
    @Published var title: String
    @Published var isFavorite: Bool

    private let document: Document
    private let context = PersistenceController.shared.viewContext

    init(document: Document) {
        self.document = document
        self.title = document.title ?? ""
        self.isFavorite = document.isFavorite
    }

    func saveChanges() async throws {
        document.title = title
        document.isFavorite = isFavorite
        document.isSynced = false
        try context.save()

        if NetworkMonitor.shared.isConnected {
            print("Internet connected")
            try await syncToServer()
        } else {
            print("No internet.")
        }
    }


    private func syncToServer() async throws {
        let dto = DocumentDTO(
            docId: document.id ?? UUID().uuidString,
            docName: document.title ?? "Untitled",
            createdDate: formatDate(document.createdAt),
            isFavourite: document.isFavorite
        )

        try await APIService.shared.updateDocument(dto)
        document.isSynced = true
        try context.save()
    }

    private func formatDate(_ date: Date?) -> String {
        guard let date = date else { return "Unknown Date" }
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
        return formatter.string(from: date)
    }
}
