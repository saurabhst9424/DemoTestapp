import Foundation
import CoreData

@MainActor
class DocumentListViewModel: ObservableObject {
    @Published var documents: [Document] = []
    private let context: NSManagedObjectContext

    init(context: NSManagedObjectContext = PersistenceController.shared.viewContext) {
            self.context = context
            fetchLocalDocuments()
        }

    func fetchLocalDocuments() {
        let request: NSFetchRequest<Document> = Document.fetchRequest()
        request.sortDescriptors = [NSSortDescriptor(keyPath: \Document.createdAt, ascending: false)]
        documents = (try? context.fetch(request)) ?? []
    }

    func fetchFromServerIfNeeded() async {
        let hasFetched = UserDefaults.standard.bool(forKey: "hasFetchedDocuments")
        guard !hasFetched else { return }

        do {
            let remoteDocs = try await APIService.shared.fetchDocuments()
            for dto in remoteDocs {
                let doc = Document(context: context)
                doc.id = dto.docId
                doc.title = dto.docName
                doc.isFavorite = dto.isFavourite
                doc.isSynced = true
                doc.createdAt = Date()
            }
            try context.save()
            UserDefaults.standard.set(true, forKey: "hasFetchedDocuments")
            fetchLocalDocuments()
        } catch {
            print("\(error)")
        }
    }

    func delete(_ document: Document) async {
        context.delete(document)
        do {
            if let id = document.id {
                try await APIService.shared.deleteDocument(id: id)
            }
            try context.save()
            fetchLocalDocuments()
        } catch {
            print("\(error)")
        }
    }

    func createDocument(title: String, isFavorite: Bool) async {
        let newDocument = Document(context: context)
        let uuid = UUID().uuidString

        newDocument.id = uuid
        newDocument.title = title
        newDocument.isFavorite = isFavorite
        newDocument.isSynced = false
        newDocument.isDelet = false
        newDocument.createdAt = Date()

        try? context.save()

        if NetworkMonitor.shared.isConnected {
            try? await syncToServer(document: newDocument)
        }

        fetchLocalDocuments()
    }

    private func syncToServer(document: Document) async throws {
        let dto = DocumentDTO(
            docId: document.id ?? UUID().uuidString,
            docName: document.title ?? "Untitled",
            createdDate: formatDate(document.createdAt),
            isFavourite: document.isFavorite
        )

        try await APIService.shared.createDocument(dto)
        document.isSynced = true
        try context.save()
    }

    private func formatDate(_ date: Date?) -> String {
        guard let date = date else { return "1970-01-01T00:00:00Z" }
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
        return formatter.string(from: date)
    }
}
