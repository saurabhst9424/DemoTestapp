import Foundation
import CoreData

@MainActor
class DocumentCreateViewModel: ObservableObject {
    @Published var title: String = ""
    @Published var isFavorite: Bool = false

    private let context = PersistenceController.shared.viewContext

    func createDocument() async throws {
        let newDocument = Document(context: context)
        let uuid = UUID().uuidString

        newDocument.id = uuid
        newDocument.title = title
        newDocument.isFavorite = isFavorite
        newDocument.isSynced = false
        newDocument.isDelet = false
        newDocument.createdAt = Date()

        try context.save()

        if NetworkMonitor.shared.isConnected {
            try await syncToServer(document: newDocument)
        }
    }

    private func syncToServer(document: Document) async throws {
        let dto = DocumentDTO(
            docId: document.id ?? UUID().uuidString,
            docName: document.title ?? "Untitled",
            createdDate: formatDate(document.createdAt),
            isFavourite: document.isFavorite
        )

        try await APIService.shared.createDocument(dto)
        document.isSynced = true
        try context.save()
    }

    private func formatDate(_ date: Date?) -> String {
        guard let date = date else { return "1970-01-01T00:00:00Z" }
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
        return formatter.string(from: date)
    }
}
