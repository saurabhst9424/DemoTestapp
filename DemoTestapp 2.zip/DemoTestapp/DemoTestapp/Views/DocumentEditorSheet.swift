import SwiftUI

struct DocumentEditorSheet: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel: DocumentEditViewModel
    var onSave: () -> Void

    init(document: Document, onSave: @escaping () -> Void) {
        _viewModel = StateObject(wrappedValue: DocumentEditViewModel(document: document))
        self.onSave = onSave
    }

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Document Title")) {
                    TextField("Enter title", text: $viewModel.title)
                }

                Toggle("Favorite", isOn: $viewModel.isFavorite)
            }
            .navigationTitle("Edit Document")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        Task {
                            do {
                                try await viewModel.saveChanges() 
                                onSave()
                                dismiss()
                            } catch {
                                print("Failed to save document:\(error.localizedDescription)")
   
                            }
                        }
                    }
                }

                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel", role: .cancel) {
                        dismiss()
                    }
                }
            }
        }
    }
}
