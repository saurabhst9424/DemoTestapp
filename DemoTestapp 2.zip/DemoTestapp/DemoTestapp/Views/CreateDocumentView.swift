

import SwiftUI

struct CreateDocumentView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var title: String = ""
    @State private var isFavorite: Bool = false

    var onCreate: (_ title: String, _ isFavorite: Bool) -> Void

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Document Title")) {
                    TextField("Enter title", text: $title)
                }

                Toggle("Favorite", isOn: $isFavorite)
            }
            .navigationTitle("New Document")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Create") {
                        if !title.isEmpty {
                            onCreate(title, isFavorite)
                            dismiss()
                        }
                    }
                }

                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel", role: .cancel) {
                        dismiss()
                    }
                }
            }
        }
    }
}

