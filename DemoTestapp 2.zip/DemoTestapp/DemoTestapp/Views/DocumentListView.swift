

import SwiftUI

struct DocumentListView: View {
    @StateObject var viewModel = DocumentListViewModel()
    
    @State private var showingCreateDocument = false
    @State private var showingEditSheet = false
    @State private var editingDocument: Document?

    var body: some View {
        NavigationView {
            List {
                ForEach(viewModel.documents) { doc in
                    HStack {
                        Text(doc.title ?? "Untitled")
                        Spacer()
                        if doc.isFavorite {
                            Image(systemName: "star.fill").foregroundColor(.yellow)
                        }
                    }
                
                    .swipeActions(edge: .trailing) {
                        Button(role: .destructive) {
                            Task {
                                await viewModel.delete(doc)
                            }
                        } label: {
                            Label("Delete", systemImage: "trash")
                        }
                    }


                    .swipeActions(edge: .leading) {
                        Button {
                            editingDocument = doc
                            showingEditSheet = true
                        } label: {
                            Label("Edit", systemImage: "pencil")
                        }
                    }
                }
            }
            .navigationTitle("Documents")
            .toolbar {
                // MARK: Create New Document
                Button {
                    showingCreateDocument = true
                } label: {
                    Image(systemName: "plus")
                }
            }
            .task {
                
                await viewModel.fetchFromServerIfNeeded()
            }


            .sheet(isPresented: $showingCreateDocument) {
                CreateDocumentView { title, isFavorite in
                    Task {
                        await viewModel.createDocument(title: title, isFavorite: isFavorite)
                    }
                }
            }

          
            .sheet(isPresented: $showingEditSheet) {
                if let doc = editingDocument {
                    DocumentEditorSheet(document: doc) {
                        Task {
                           
                            viewModel.fetchLocalDocuments()
                        }
                    }
                }
            }
        }
    }
}

#Preview {
    DocumentListView()
}
