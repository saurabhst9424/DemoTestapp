
import SwiftUI

struct FavoriteDocumentsView: View {
    @FetchRequest(
        entity: Document.entity(),
        sortDescriptors: [NSSortDescriptor(keyPath: \Document.createdAt, ascending: false)],
        predicate: NSPredicate(format: "isFavorite == YES")
    ) var favoriteDocs: FetchedResults<Document>

    var body: some View {
        NavigationView {
            List(favoriteDocs) { doc in
                HStack {
                    Text(doc.title ?? "Untitled")
                    Spacer()
                    Image(systemName: "star.fill").foregroundColor(.yellow)
                }
            }
            .navigationTitle("Favorites")
        }
    }
}

#Preview {
    FavoriteDocumentsView()
}
