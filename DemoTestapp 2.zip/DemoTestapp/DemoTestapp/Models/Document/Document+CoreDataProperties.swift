import Foundation
import CoreData


extension Document {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Document> {
        return NSFetchRequest<Document>(entityName: "Document")
    }

    @NSManaged public var id: String?
    @NSManaged public var title: String?
    @NSManaged public var isFavorite: Bool
    @NSManaged public var isSynced: Bool
    @NSManaged public var isDelet: Bool
    @NSManaged public var createdAt: Date?

}

extension Document : Identifiable {

}
