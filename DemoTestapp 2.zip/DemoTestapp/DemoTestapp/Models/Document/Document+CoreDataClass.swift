import Foundation
import CoreData

@objc(Document)
public class Document: NSManagedObject {

}
