
import Foundation

struct DocumentDTO: Identifiable, Codable {
    var id: String { docId }
    let docId: String
    let docName: String
    let createdDate: String
    let isFavourite: Bool
}

