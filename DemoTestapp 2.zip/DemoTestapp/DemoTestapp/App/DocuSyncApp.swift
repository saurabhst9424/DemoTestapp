import SwiftUI

@main
struct DocuSyncApp: App {
    let persistenceController = PersistenceController.shared
    @StateObject private var networkMonitor = NetworkMonitor.shared

    var body: some Scene {
        WindowGroup {
            AppRouter()
                .environment(\.managedObjectContext, persistenceController.viewContext)
                .environmentObject(networkMonitor)
        }
    }
}
