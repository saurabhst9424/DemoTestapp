import SwiftUI

struct AppRouter: View {
    var body: some View {
        TabView {
            DocumentListView()
                .tabItem {
                    Label("Home", systemImage: "doc.text")
                }

            FavoriteDocumentsView()
                .tabItem {
                    Label("Favorites", systemImage: "star.fill")
                }
        }
        .preferredColorScheme(nil)
        
    }
}
